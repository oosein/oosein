"use client"

import { createContext, useContext, useEffect, useState } from "react"

type Language = "pt" | "en"

interface LanguageContextType {
  language: Language
  toggleLanguage: () => void
  t: (key: string) => string
}

const translations: Record<Language, Record<string, string>> = {
  pt: {
    "nav.about": "Sobre",
    "nav.skills": "Habilidades",
    "nav.servers": "Servidores",
    "nav.contact": "Contato",
    "hero.greeting": "Olá, eu sou",
    "hero.role": "Moderador Discord",
    "hero.description": "Ajudo comunidades a se manterem organizadas e saudáveis.",
    "about.title": "Sobre Mim",
    "about.text": "Sou um moderador de Discord experiente, focado em manter comunidades organizadas e acolhedoras. Tenho paixão por ajudar pessoas e criar ambientes onde todos se sintam bem-vindos. Minha experiência inclui moderação de servidores de grande porte e gerenciamento de equipes.",
    "skills.title": "Habilidades",
    "skills.moderation": "Moderação",
    "skills.community": "Gestão de Comunidade",
    "skills.communication": "Comunicação",
    "skills.conflict": "Resolução de Conflitos",
    "skills.organization": "Organização",
    "servers.title": "Servidores",
    "contact.title": "Conecte Comigo",
    "contact.text": "Precisa de ajuda no seu servidor? Pode me chamar no Discord.",
    "contact.button": "Chamar no Discord",
    "footer.role": "Discord Moderator",
  },
  en: {
    "nav.about": "About",
    "nav.skills": "Skills",
    "nav.servers": "Servers",
    "nav.contact": "Contact",
    "hero.greeting": "Hello, I'm",
    "hero.role": "Discord Moderator",
    "hero.description": "I help communities stay organized and healthy.",
    "about.title": "About Me",
    "about.text": "I'm an experienced Discord moderator, focused on keeping communities organized and welcoming. I have a passion for helping people and creating environments where everyone feels welcome. My experience includes moderating large servers and managing teams.",
    "skills.title": "Skills",
    "skills.moderation": "Moderation",
    "skills.community": "Community Management",
    "skills.communication": "Communication",
    "skills.conflict": "Conflict Resolution",
    "skills.organization": "Organization",
    "servers.title": "Servers",
    "contact.title": "Connect With Me",
    "contact.text": "Need help with your server? Feel free to reach out on Discord.",
    "contact.button": "Message on Discord",
    "footer.role": "Discord Moderator",
  },
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>("pt")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const stored = localStorage.getItem("language") as Language | null
    if (stored) {
      setLanguage(stored)
    }
  }, [])

  useEffect(() => {
    if (mounted) {
      localStorage.setItem("language", language)
    }
  }, [language, mounted])

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === "pt" ? "en" : "pt"))
  }

  const t = (key: string): string => {
    return translations[language][key] || key
  }

  if (!mounted) {
    return null
  }

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
