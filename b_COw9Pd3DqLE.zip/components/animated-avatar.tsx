"use client"

import { motion } from "framer-motion"
import Image from "next/image"

export function AnimatedAvatar() {
  return (
    <div className="relative flex items-center justify-center">
      {/* Anel fino girando */}
      <motion.div
        className="absolute h-52 w-52 rounded-full border border-[#aaaaaa]/20"
        animate={{ rotate: 360 }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear",
        }}
      />

      {/* Anel externo com glow */}
      <motion.div
        className="absolute h-48 w-48 rounded-full"
        style={{
          background: "transparent",
          boxShadow: "0 0 30px 2px rgba(170, 170, 170, 0.15)",
        }}
        animate={{
          boxShadow: [
            "0 0 30px 2px rgba(170, 170, 170, 0.15)",
            "0 0 40px 4px rgba(170, 170, 170, 0.25)",
            "0 0 30px 2px rgba(170, 170, 170, 0.15)",
          ],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Bolinha orbitando */}
      <motion.div
        className="absolute h-48 w-48"
        animate={{ rotate: 360 }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "linear",
        }}
      >
        <motion.div
          className="absolute -top-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rounded-full"
          style={{
            background: "#aaaaaa",
            boxShadow: "0 0 10px 3px rgba(170, 170, 170, 0.4)",
          }}
        />
        {/* Rastro suave */}
        <motion.div
          className="absolute -top-1 left-1/2 h-2 w-8 -translate-x-1/2 rounded-full opacity-30"
          style={{
            background: "linear-gradient(90deg, transparent, #aaaaaa)",
            transform: "translateX(-50%) rotate(-30deg)",
            transformOrigin: "right center",
          }}
        />
      </motion.div>

      {/* Avatar principal */}
      <motion.div
        className="relative h-40 w-40 overflow-hidden rounded-full"
        style={{
          boxShadow: "0 0 25px 5px rgba(170, 170, 170, 0.2)",
        }}
        whileHover={{
          scale: 1.05,
          boxShadow: "0 0 35px 8px rgba(170, 170, 170, 0.3)",
        }}
        transition={{ duration: 0.3 }}
      >
        <Image
          src="https://i.pinimg.com/736x/93/c6/6e/93c66e735b6c02afb07c3ba23480dfd7.jpg"
          alt="oSein Avatar"
          fill
          className="object-cover"
          priority
        />
      </motion.div>
    </div>
  )
}
