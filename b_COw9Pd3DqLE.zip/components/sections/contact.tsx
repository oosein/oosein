"use client"

import { motion } from "framer-motion"
import { useLanguage } from "@/components/providers/language-provider"
import { useTheme } from "@/components/providers/theme-provider"
import { DiscordIcon } from "@/components/discord-icon"

export function ContactSection() {
  const { t } = useLanguage()
  const { theme } = useTheme()

  return (
    <section id="contact" className="px-4 py-24">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true, margin: "-100px" }}
        className="mx-auto max-w-md"
      >
        <motion.h2
          className="mb-8 text-center text-2xl font-bold text-[#e5e5e5] dark:text-[#e5e5e5] light:text-[#1a1a1a]"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          viewport={{ once: true }}
        >
          {t("contact.title")}
        </motion.h2>

        <motion.div
          className="flex flex-col items-center rounded-2xl border border-[#2a2a2a] bg-gradient-to-br from-[#1a1a1a] to-[#222222] p-8 text-center shadow-xl dark:border-[#2a2a2a] dark:from-[#1a1a1a] dark:to-[#222222] light:border-[#e0e0e0] light:from-[#f5f5f5] light:to-[#ffffff]"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          whileHover={{
            boxShadow: "0 0 30px rgba(170, 170, 170, 0.15)",
          }}
          transition={{ duration: 0.3 }}
          viewport={{ once: true }}
          style={{
            boxShadow: "0 8px 32px rgba(0, 0, 0, 0.3)",
          }}
        >
          <p className="mb-6 text-[#aaaaaa] leading-relaxed dark:text-[#aaaaaa] light:text-[#555555]">
            {t("contact.text")}
          </p>

          <motion.a
            href="https://discord.com/users/1077000858342006867"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 rounded-xl bg-gradient-to-r from-[#2a2a2a] to-[#3a3a3a] px-6 py-3 text-sm font-medium text-[#e5e5e5] shadow-lg dark:from-[#2a2a2a] dark:to-[#3a3a3a] light:from-[#e5e5e5] light:to-[#f5f5f5] light:text-[#1a1a1a]"
            whileHover={{
              scale: 1.02,
              y: -3,
              boxShadow: "0 0 25px rgba(170, 170, 170, 0.25)",
            }}
            whileTap={{ scale: 0.98 }}
            style={{
              boxShadow: "0 4px 20px rgba(0, 0, 0, 0.3)",
            }}
          >
            <DiscordIcon className="h-5 w-5" dark={theme === "dark"} />
            <span>{t("contact.button")}</span>
          </motion.a>
        </motion.div>
      </motion.div>
    </section>
  )
}
