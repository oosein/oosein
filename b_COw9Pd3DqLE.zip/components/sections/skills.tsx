"use client"

import { motion } from "framer-motion"
import { useState } from "react"
import { useLanguage } from "@/components/providers/language-provider"

const skills = [
  { key: "skills.moderation", level: 95 },
  { key: "skills.community", level: 90 },
  { key: "skills.communication", level: 88 },
  { key: "skills.conflict", level: 85 },
  { key: "skills.organization", level: 92 },
]

function SkillBar({ name, level, index }: { name: string; level: number; index: number }) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, x: -30 }}
      whileInView={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="group"
    >
      <div className="mb-2 flex items-center justify-between">
        <span className="text-sm text-[#aaaaaa] transition-colors group-hover:text-[#e5e5e5] dark:group-hover:text-[#e5e5e5] light:text-[#555555] light:group-hover:text-[#1a1a1a]">
          {name}
        </span>
        <span className="text-xs text-[#888888] dark:text-[#888888] light:text-[#777777]">
          {level}%
        </span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-[#2a2a2a] dark:bg-[#2a2a2a] light:bg-[#e0e0e0]">
        <motion.div
          className="h-full rounded-full"
          initial={{ width: 0 }}
          whileInView={{ width: `${level}%` }}
          transition={{ duration: 1, delay: index * 0.1 + 0.3, ease: "easeOut" }}
          viewport={{ once: true }}
          style={{
            background: isHovered
              ? "linear-gradient(90deg, #888888, #aaaaaa)"
              : "linear-gradient(90deg, #555555, #888888)",
            boxShadow: isHovered ? "0 0 15px rgba(170, 170, 170, 0.4)" : "none",
            transition: "background 0.3s, box-shadow 0.3s",
          }}
        />
      </div>
    </motion.div>
  )
}

export function SkillsSection() {
  const { t } = useLanguage()

  return (
    <section id="skills" className="px-4 py-24">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true, margin: "-100px" }}
        className="mx-auto max-w-2xl"
      >
        <motion.h2
          className="mb-10 text-center text-2xl font-bold text-[#e5e5e5] dark:text-[#e5e5e5] light:text-[#1a1a1a]"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          viewport={{ once: true }}
        >
          {t("skills.title")}
        </motion.h2>

        <motion.div
          className="rounded-2xl border border-[#2a2a2a] bg-gradient-to-br from-[#1a1a1a] to-[#222222] p-8 shadow-xl dark:border-[#2a2a2a] dark:from-[#1a1a1a] dark:to-[#222222] light:border-[#e0e0e0] light:from-[#f5f5f5] light:to-[#ffffff]"
          whileHover={{
            boxShadow: "0 0 30px rgba(170, 170, 170, 0.1)",
          }}
          style={{
            boxShadow: "0 8px 32px rgba(0, 0, 0, 0.3)",
          }}
        >
          <div className="flex flex-col gap-6">
            {skills.map((skill, index) => (
              <SkillBar
                key={skill.key}
                name={t(skill.key)}
                level={skill.level}
                index={index}
              />
            ))}
          </div>
        </motion.div>
      </motion.div>
    </section>
  )
}
