"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { useLanguage } from "@/components/providers/language-provider"
import { useTheme } from "@/components/providers/theme-provider"
import { DiscordIcon } from "@/components/discord-icon"

const servers = [
  {
    name: "Anime Crash",
    image: "https://osein.vercel.app/assets/Anime%20Crash.webp",
    invite: "https://discord.gg/K5gSxMUsm",
    role: "Moderator (Retired)",
    descPt: "Ajudei a manter o servidor organizado e a comunidade ativa.",
    descEn: "Helped keep the server organized and the community active.",
  },
  {
    name: "Anime Brawl",
    image: "https://osein.vercel.app/assets/Anime%20Brawl.png",
    invite: "https://discord.gg/xCN3kvCwzG",
    role: "Trial Moderator",
    descPt: "Cuido da moderação e mantenho o chat organizado.",
    descEn: "I take care of moderation and keep the chat organized.",
  },
  {
    name: "Anime All",
    image: "https://osein.vercel.app/assets/AL.webp",
    invite: "https://discord.com/invite/CkVnGNm3Ct",
    role: "Moderator (Retired)",
    descPt: "Auxiliei a equipe e ajudei no controle do servidor.",
    descEn: "Assisted the team and helped manage the server.",
  },
  {
    name: "Anime Paradise",
    image: "https://cdn.discordapp.com/icons/1478021532969078908/9240e8e4521081a23596c62f30196aa2.png?size=2048",
    invite: "https://discord.gg/P8J8DzcvK3",
    role: "Moderator",
    descPt: "Atualmente moderando e apoiando a comunidade.",
    descEn: "Currently moderating and supporting the community.",
  },
]

function ServerCard({
  server,
  index,
}: {
  server: (typeof servers)[0]
  index: number
}) {
  const { language } = useLanguage()
  const { theme } = useTheme()

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      whileHover={{
        scale: 1.02,
        y: -5,
        boxShadow: "0 0 25px rgba(170, 170, 170, 0.15)",
      }}
      className="group flex flex-col items-center rounded-2xl border border-[#2a2a2a] bg-gradient-to-br from-[#1a1a1a] to-[#222222] p-6 shadow-lg dark:border-[#2a2a2a] dark:from-[#1a1a1a] dark:to-[#222222] light:border-[#e0e0e0] light:from-[#f5f5f5] light:to-[#ffffff]"
      style={{
        boxShadow: "0 4px 20px rgba(0, 0, 0, 0.2)",
      }}
    >
      {/* Imagem do servidor */}
      <motion.div
        className="relative mb-4 h-16 w-16 overflow-hidden rounded-xl"
        whileHover={{ scale: 1.05 }}
        style={{
          boxShadow: "0 0 15px rgba(170, 170, 170, 0.1)",
        }}
      >
        <Image
          src={server.image}
          alt={server.name}
          fill
          className="object-cover"
        />
      </motion.div>

      {/* Nome */}
      <h3 className="mb-1 text-center text-base font-semibold text-[#e5e5e5] dark:text-[#e5e5e5] light:text-[#1a1a1a]">
        {server.name}
      </h3>

      {/* Cargo */}
      <span className="mb-3 text-xs text-[#888888] dark:text-[#888888] light:text-[#777777]">
        {server.role}
      </span>

      {/* Descrição */}
      <p className="mb-4 text-center text-xs leading-relaxed text-[#aaaaaa] dark:text-[#aaaaaa] light:text-[#555555]">
        {language === "pt" ? server.descPt : server.descEn}
      </p>

      {/* Botão */}
      <motion.a
        href={server.invite}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-[#2a2a2a] to-[#3a3a3a] px-4 py-2 text-xs font-medium text-[#e5e5e5] shadow-md transition-all dark:from-[#2a2a2a] dark:to-[#3a3a3a] light:from-[#e5e5e5] light:to-[#f5f5f5] light:text-[#1a1a1a]"
        whileHover={{
          scale: 1.05,
          boxShadow: "0 0 15px rgba(170, 170, 170, 0.2)",
        }}
        whileTap={{ scale: 0.98 }}
      >
        <DiscordIcon className="h-4 w-4" dark={theme === "dark"} />
        <span>Entrar</span>
      </motion.a>
    </motion.div>
  )
}

export function ServersSection() {
  const { t } = useLanguage()

  return (
    <section id="servers" className="px-4 py-24">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true, margin: "-100px" }}
        className="mx-auto max-w-4xl"
      >
        <motion.h2
          className="mb-10 text-center text-2xl font-bold text-[#e5e5e5] dark:text-[#e5e5e5] light:text-[#1a1a1a]"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          viewport={{ once: true }}
        >
          {t("servers.title")}
        </motion.h2>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {servers.map((server, index) => (
            <ServerCard key={server.name} server={server} index={index} />
          ))}
        </div>
      </motion.div>
    </section>
  )
}
