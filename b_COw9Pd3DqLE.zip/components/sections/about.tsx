"use client"

import { motion } from "framer-motion"
import { useLanguage } from "@/components/providers/language-provider"

export function AboutSection() {
  const { t } = useLanguage()

  return (
    <section id="about" className="px-4 py-24">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true, margin: "-100px" }}
        className="mx-auto max-w-2xl"
      >
        <motion.h2
          className="mb-8 text-center text-2xl font-bold text-[#e5e5e5] dark:text-[#e5e5e5] light:text-[#1a1a1a]"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          viewport={{ once: true }}
        >
          {t("about.title")}
        </motion.h2>

        <motion.div
          className="rounded-2xl border border-[#2a2a2a] bg-gradient-to-br from-[#1a1a1a] to-[#222222] p-8 shadow-xl dark:border-[#2a2a2a] dark:from-[#1a1a1a] dark:to-[#222222] light:border-[#e0e0e0] light:from-[#f5f5f5] light:to-[#ffffff]"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          whileHover={{
            scale: 1.01,
            boxShadow: "0 0 30px rgba(170, 170, 170, 0.1)",
          }}
          transition={{ duration: 0.3 }}
          viewport={{ once: true }}
          style={{
            boxShadow: "0 8px 32px rgba(0, 0, 0, 0.3)",
          }}
        >
          <p className="text-center text-[#aaaaaa] leading-relaxed dark:text-[#aaaaaa] light:text-[#555555]">
            {t("about.text")}
          </p>
        </motion.div>
      </motion.div>
    </section>
  )
}
