"use client"

import { motion } from "framer-motion"
import { AnimatedAvatar } from "@/components/animated-avatar"
import { useLanguage } from "@/components/providers/language-provider"

export function HeroSection() {
  const { t } = useLanguage()

  return (
    <section className="relative flex min-h-screen items-center justify-center overflow-hidden px-4 pt-20">
      {/* Fundo com gradiente e glow sutil */}
      <div className="absolute inset-0 -z-10">
        <motion.div
          className="absolute top-1/4 left-1/4 h-96 w-96 rounded-full opacity-20"
          style={{
            background: "radial-gradient(circle, rgba(170, 170, 170, 0.3) 0%, transparent 70%)",
          }}
          animate={{
            x: [0, 50, 0],
            y: [0, 30, 0],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <motion.div
          className="absolute right-1/4 bottom-1/4 h-80 w-80 rounded-full opacity-15"
          style={{
            background: "radial-gradient(circle, rgba(170, 170, 170, 0.25) 0%, transparent 70%)",
          }}
          animate={{
            x: [0, -40, 0],
            y: [0, -20, 0],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </div>

      <div className="flex flex-col items-center gap-8 text-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <AnimatedAvatar />
        </motion.div>

        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-col gap-3"
        >
          <p className="text-sm text-[#aaaaaa] dark:text-[#aaaaaa] light:text-[#666666]">
            {t("hero.greeting")}
          </p>
          <h1 className="text-4xl font-bold text-[#e5e5e5] dark:text-[#e5e5e5] light:text-[#1a1a1a] md:text-5xl">
            oSein
          </h1>
          <p className="text-lg text-[#aaaaaa] dark:text-[#aaaaaa] light:text-[#666666]">
            {t("hero.role")}
          </p>
        </motion.div>

        <motion.p
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="max-w-md text-sm text-[#888888] dark:text-[#888888] light:text-[#777777]"
        >
          {t("hero.description")}
        </motion.p>

        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="flex gap-4"
        >
          <motion.a
            href="#contact"
            className="rounded-xl bg-gradient-to-r from-[#1a1a1a] to-[#2a2a2a] px-6 py-3 text-sm font-medium text-[#e5e5e5] shadow-lg transition-all dark:from-[#1a1a1a] dark:to-[#2a2a2a] light:from-[#e5e5e5] light:to-[#ffffff] light:text-[#1a1a1a]"
            whileHover={{
              scale: 1.02,
              y: -3,
              boxShadow: "0 0 20px rgba(170, 170, 170, 0.2)",
            }}
            whileTap={{ scale: 0.98 }}
            style={{
              boxShadow: "0 4px 20px rgba(0, 0, 0, 0.3)",
            }}
          >
            {t("contact.button")}
          </motion.a>
        </motion.div>
      </div>
    </section>
  )
}
