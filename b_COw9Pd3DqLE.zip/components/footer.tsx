"use client"

import { motion } from "framer-motion"
import { useLanguage } from "@/components/providers/language-provider"

export function Footer() {
  const { t } = useLanguage()

  return (
    <motion.footer
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
      viewport={{ once: true }}
      className="border-t border-[#2a2a2a] px-4 py-8 dark:border-[#2a2a2a] light:border-[#e0e0e0]"
    >
      <div className="mx-auto max-w-4xl text-center">
        <p className="text-sm text-[#888888] dark:text-[#888888] light:text-[#777777]">
          © 2026 oSein - {t("footer.role")}
        </p>
      </div>
    </motion.footer>
  )
}
