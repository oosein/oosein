"use client"

import { motion } from "framer-motion"
import { Moon, Sun, Globe } from "lucide-react"
import { useTheme } from "@/components/providers/theme-provider"
import { useLanguage } from "@/components/providers/language-provider"

export function Navbar() {
  const { theme, toggleTheme } = useTheme()
  const { language, toggleLanguage, t } = useLanguage()

  const navItems = [
    { href: "#about", label: t("nav.about") },
    { href: "#skills", label: t("nav.skills") },
    { href: "#servers", label: t("nav.servers") },
    { href: "#contact", label: t("nav.contact") },
  ]

  return (
    <motion.nav
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="fixed top-0 left-0 right-0 z-50 px-4 py-4"
    >
      <div className="mx-auto flex max-w-4xl items-center justify-between rounded-2xl bg-[#1a1a1a]/80 px-6 py-3 shadow-lg backdrop-blur-md dark:bg-[#1a1a1a]/80 light:bg-[#f5f5f5]/80">
        <motion.span
          className="text-lg font-semibold text-[#e5e5e5] dark:text-[#e5e5e5] light:text-[#1a1a1a]"
          whileHover={{ scale: 1.02 }}
        >
          oSein
        </motion.span>

        <div className="hidden items-center gap-6 md:flex">
          {navItems.map((item) => (
            <motion.a
              key={item.href}
              href={item.href}
              className="text-sm text-[#aaaaaa] transition-colors hover:text-[#e5e5e5] dark:hover:text-[#e5e5e5] light:text-[#666666] light:hover:text-[#1a1a1a]"
              whileHover={{ y: -2 }}
              transition={{ duration: 0.2 }}
            >
              {item.label}
            </motion.a>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <motion.button
            onClick={toggleLanguage}
            className="flex items-center gap-1 rounded-lg bg-[#2a2a2a] px-3 py-2 text-sm text-[#aaaaaa] shadow-md transition-all hover:bg-[#3a3a3a] hover:text-[#e5e5e5] dark:bg-[#2a2a2a] light:bg-[#e5e5e5] light:text-[#666666] light:hover:bg-[#d5d5d5] light:hover:text-[#1a1a1a]"
            whileHover={{ scale: 1.02, y: -2 }}
            whileTap={{ scale: 0.98 }}
            style={{
              boxShadow: "0 0 10px rgba(170, 170, 170, 0.1)",
            }}
          >
            <Globe className="h-4 w-4" />
            <span>{language.toUpperCase()}</span>
          </motion.button>

          <motion.button
            onClick={toggleTheme}
            className="rounded-lg bg-[#2a2a2a] p-2 text-[#aaaaaa] shadow-md transition-all hover:bg-[#3a3a3a] hover:text-[#e5e5e5] dark:bg-[#2a2a2a] light:bg-[#e5e5e5] light:text-[#666666] light:hover:bg-[#d5d5d5] light:hover:text-[#1a1a1a]"
            whileHover={{ scale: 1.02, y: -2 }}
            whileTap={{ scale: 0.98 }}
            style={{
              boxShadow: "0 0 10px rgba(170, 170, 170, 0.1)",
            }}
          >
            {theme === "dark" ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Moon className="h-4 w-4" />
            )}
          </motion.button>
        </div>
      </div>
    </motion.nav>
  )
}
